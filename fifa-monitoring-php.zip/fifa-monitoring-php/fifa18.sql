-- Create the database
CREATE DATABASE IF NOT EXISTS fifa18;
USE fifa18;

-- Drop existing tables if needed
DROP TABLE IF EXISTS favorites;
DROP TABLE IF EXISTS players;

-- Create players table with more fields
CREATE TABLE players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    club VARCHAR(100),
    overall INT,
    age INT,
    nationality VARCHAR(100),
    position VARCHAR(50)
);

-- Create favorites table
CREATE TABLE favorites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    player_id INT,
    FOREIGN KEY (player_id) REFERENCES players(id)
);

-- Insert updated sample data
INSERT INTO players (name, club, overall, age, nationality, position) VALUES
('Lionel Messi', 'FC Barcelona', 94, 30, 'Argentina', 'RW'),
('Cristiano Ronaldo', 'Real Madrid', 94, 32, 'Portugal', 'ST'),
('Neymar Jr', 'Paris Saint-Germain', 92, 25, 'Brazil', 'LW'),
('Luka Modrić', 'Real Madrid', 89, 31, 'Croatia', 'CM'),
('Kevin De Bruyne', 'Manchester City', 89, 26, 'Belgium', 'CAM'),
('Robert Lewandowski', 'Bayern Munich', 91, 29, 'Poland', 'ST'),
('Sergio Ramos', 'Real Madrid', 90, 31, 'Spain', 'CB'),
('Kylian Mbappé', 'Paris Saint-Germain', 83, 18, 'France', 'ST'),
('Paul Pogba', 'Manchester United', 88, 24, 'France', 'CM'),
('Eden Hazard', 'Chelsea', 90, 26, 'Belgium', 'LW');
