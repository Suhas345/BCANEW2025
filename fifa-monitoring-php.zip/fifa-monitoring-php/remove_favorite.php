<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $conn->query("DELETE FROM favorites WHERE id = $id");
}

header("Location: favorites.php");
exit;
