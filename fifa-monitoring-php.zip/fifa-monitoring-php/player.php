<?php
include 'db.php';

$id = intval($_GET['id'] ?? 0);
$result = $conn->query("SELECT * FROM players WHERE id = $id");

if ($result->num_rows == 0) {
    echo "<h2>Player not found</h2>";
    exit;
}

$player = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= $player['name'] ?> - Player Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">

<div class="container mt-5">
    <a href="index.php" class="btn btn-light mb-4">← Back to Players List</a>

    <div class="card text-bg-secondary p-4">
        <h2><?= $player['name'] ?></h2>
        <p><strong>Club:</strong> <?= $player['club'] ?></p>
        <p><strong>Overall Rating:</strong> <?= $player['overall'] ?></p>

        <a href="add_favorite.php?id=<?= $player['id'] ?>" class="btn btn-success">Add to Favorites</a>
    </div>
</div>

</body>
</html>
