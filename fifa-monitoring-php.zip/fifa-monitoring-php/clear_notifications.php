<?php
include 'db.php';
$conn->query("DELETE FROM notifications");
header("Location: index.php");
exit;
?>
