<?php
include 'db.php';

$notifications = $conn->query("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 5");

if ($notifications->num_rows > 0): ?>
    <div class="alert alert-warning d-flex justify-content-between align-items-center">
        <div>
            <strong>🔔 Recent Notifications:</strong>
            <ul class="mb-0">
                <?php while($note = $notifications->fetch_assoc()): ?>
                    <li><?= htmlspecialchars($note['message']) ?> <small class="text-muted">(<?= $note['created_at'] ?>)</small></li>
                <?php endwhile; ?>
            </ul>
        </div>
        <a href="clear_notifications.php" class="btn btn-sm btn-danger ms-3">Clear All</a>
    </div>
<?php endif; ?>
