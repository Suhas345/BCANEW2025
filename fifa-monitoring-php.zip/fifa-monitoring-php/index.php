<?php
include 'db.php';

$search = $_GET['search'] ?? '';
$sort = $_GET['sort'] ?? '';
$order = '';

if ($sort === 'name') $order = 'ORDER BY name ASC';
if ($sort === 'overall') $order = 'ORDER BY overall DESC';

$sql = "SELECT * FROM players WHERE name LIKE '%$search%' $order LIMIT 100";
$result = $conn->query($sql);

// Initial notification fetch
$notifications = $conn->query("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 5");
?>

<!DOCTYPE html>
<html>
<head>
    <title>FIFA 18 Player Monitoring</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        // Auto-refresh notifications every 10 seconds
        setInterval(() => {
            fetch('notifications_ajax.php')
                .then(res => res.text())
                .then(html => document.getElementById('notifications').innerHTML = html);
        }, 10000);
    </script>
</head>
<body class="bg-dark text-white">

<div class="container mt-5">
    <h1 class="mb-4">⚽ FIFA 18 Players Monitoring</h1>

    <!-- Notifications Section -->
    <div id="notifications">
        <?php if ($notifications->num_rows > 0): ?>
            <div class="alert alert-warning d-flex justify-content-between align-items-center">
                <div>
                    <strong>🔔 Recent Notifications:</strong>
                    <ul class="mb-0">
                        <?php while($note = $notifications->fetch_assoc()): ?>
                            <li><?= htmlspecialchars($note['message']) ?> <small class="text-muted">(<?= $note['created_at'] ?>)</small></li>
                        <?php endwhile; ?>
                    </ul>
                </div>
                <a href="clear_notifications.php" class="btn btn-sm btn-danger ms-3">Clear All</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Filter and Sort -->
    <form method="get" class="mb-3 d-flex gap-2">
        <input type="text" name="search" placeholder="Search players..." class="form-control" value="<?= htmlspecialchars($search) ?>">
        <select name="sort" class="form-select w-auto">
            <option value="">Sort By</option>
            <option value="name" <?= ($sort === 'name') ? 'selected' : '' ?>>Name (A-Z)</option>
            <option value="overall" <?= ($sort === 'overall') ? 'selected' : '' ?>>Overall (High to Low)</option>
        </select>
        <button class="btn btn-primary">Apply</button>
    </form>

    <!-- Player Table -->
    <table class="table table-dark table-hover">
        <thead>
            <tr>
                <th>Name</th>
                <th>Club</th>
                <th>Overall</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td>
                    <a href="player.php?id=<?= $row['id'] ?>" class="text-info text-decoration-none">
                        <?= $row['name'] ?>
                    </a>
                </td>
                <td><?= $row['club'] ?></td>
                <td><?= $row['overall'] ?></td>
                <td>
                    <a href="add_favorite.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-success">Add to Favorite</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Navigation -->
    <div class="mt-4 d-flex flex-wrap gap-2">
        <a href="favorites.php" class="btn btn-light">❤️ View Favorites</a>
        <a href="dashboard.php" class="btn btn-info">📊 View Stats Dashboard</a>
        <a href="add_player.php" class="btn btn-success">➕ Add New Player</a>
    </div>
</div>

</body>
</html>
