<?php
include 'db.php';

if (isset($_GET['id'])) {
    $player_id = (int)$_GET['id'];

    // Add to favorites
    $conn->query("INSERT IGNORE INTO favorites (player_id) VALUES ($player_id)");

    // Fetch player details to check rating
    $result = $conn->query("SELECT name, overall FROM players WHERE id = $player_id");
    if ($result && $row = $result->fetch_assoc()) {
        if ($row['overall'] >= 85) {
            $name = $conn->real_escape_string($row['name']);
            $overall = $row['overall'];
            $conn->query("INSERT INTO notifications (message) VALUES ('Top player \"$name\" added to favorites.')");
        }
    }

    header("Location: index.php");
    exit;
} else {
    echo "Player ID not found!";
}
?>
