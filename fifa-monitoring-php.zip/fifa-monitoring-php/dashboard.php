<?php
include 'db.php';

// Query 1: Player count by position
$positionData = [];
$res1 = $conn->query("SELECT position, COUNT(*) as total FROM players GROUP BY position");
while ($row = $res1->fetch_assoc()) {
    $positionData[] = $row;
}

// Query 2: Average overall by club (top 5 clubs)
$clubData = [];
$res2 = $conn->query("SELECT club, ROUND(AVG(overall), 2) as avg_overall FROM players GROUP BY club ORDER BY avg_overall DESC LIMIT 5");
while ($row = $res2->fetch_assoc()) {
    $clubData[] = $row;
}

// Query 3: Top nationalities by count (top 5)
$nationalityData = [];
$res3 = $conn->query("SELECT nationality, COUNT(*) as total FROM players GROUP BY nationality ORDER BY total DESC LIMIT 5");
while ($row = $res3->fetch_assoc()) {
    $nationalityData[] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>FIFA 18 Statistics Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
<div class="container mt-5">
    <h2 class="mb-4">📊 FIFA 18 Players Statistics Dashboard</h2>
    <a href="index.php" class="btn btn-light mb-4">← Back to Player List</a>

    <div class="row g-4">
        <!-- Position Chart -->
        <div class="col-md-6">
            <div class="card p-3 bg-secondary">
                <h5>Players by Position</h5>
                <canvas id="positionChart"></canvas>
            </div>
        </div>

        <!-- Club Chart -->
        <div class="col-md-6">
            <div class="card p-3 bg-secondary">
                <h5>Average Overall by Top 5 Clubs</h5>
                <canvas id="clubChart"></canvas>
            </div>
        </div>

        <!-- Nationality Chart -->
        <div class="col-md-12">
            <div class="card p-3 bg-secondary">
                <h5>Top 5 Nationalities by Player Count</h5>
                <canvas id="nationalityChart"></canvas>
            </div>
        </div>
    </div>
</div>

<script>
const positionCtx = document.getElementById('positionChart').getContext('2d');
const clubCtx = document.getElementById('clubChart').getContext('2d');
const nationalityCtx = document.getElementById('nationalityChart').getContext('2d');

// Position Chart
new Chart(positionCtx, {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_column($positionData, 'position')) ?>,
        datasets: [{
            label: 'Player Count',
            data: <?= json_encode(array_column($positionData, 'total')) ?>,
            backgroundColor: 'rgba(255, 206, 86, 0.6)'
        }]
    }
});

// Club Chart
new Chart(clubCtx, {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_column($clubData, 'club')) ?>,
        datasets: [{
            label: 'Average Overall',
            data: <?= json_encode(array_column($clubData, 'avg_overall')) ?>,
            backgroundColor: 'rgba(75, 192, 192, 0.6)'
        }]
    }
});

// Nationality Chart
new Chart(nationalityCtx, {
    type: 'doughnut',
    data: {
        labels: <?= json_encode(array_column($nationalityData, 'nationality')) ?>,
        datasets: [{
            label: 'Player Count',
            data: <?= json_encode(array_column($nationalityData, 'total')) ?>,
            backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF']
        }]
    }
});
</script>
</body>
</html>
